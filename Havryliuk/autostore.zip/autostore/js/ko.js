$(function() {
    var priceFilter =  $( "#slider_price" ).slider({
        range: true,
        min: 0,
        max: 0,
        values: [ 0, 0],
        slide: function( event, ui ) {
            $( "#price" ).val(ui.values[0]);
            $("#price2").val(ui.values[1]); }
    });
    $('#price').val(priceFilter.slider('values', 0)).on('change', function () {
        var val = +this.value;
        if(val >= priceFilter.slider('option','min') && val < priceFilter.slider('option','max')) {
            priceFilter.slider('values', 0, val);
        }
    });
    $('#price2').val(priceFilter.slider('values',1)).on('change', function () {
        priceFilter.slider('values', 1, +this.value);
    });

    function setFilterPrice(maxPrise) {
        if(maxPrise > +priceFilter.slider('option', 'max')){
            priceFilter.slider('option', 'max', maxPrise);
            priceFilter.slider('values', 1 , maxPrise);
            $('#price2').val(maxPrise);
        }
    }
    function Attributes() {
        this.color = ko.observableArray([]);
        this.brand = ko.observableArray([]);
        this.model = ko.observableArray([]);
        this.year = ko.observableArray([]);
    }

    function Product(title, img, price, salePrice, newAction, sale, rating, color, brand, model, year) {
        this.title = ko.observable(title || '');
        this.img = ko.observable(img || '');
        this.price = ko.observable(price || '');
        this.salePrice = ko.observable(salePrice || '');
        this.newAction = ko.observable(newAction || false);
        this.sale = ko.observable(sale || false);
        this.rating = ko.observable(rating || '');
        this.color = ko.observable(color || '');
        this.brand = ko.observable(brand || '');
        this.model = ko.observable(model || '');
        this.year= ko.observable(year || '');
        this.prices = ko.computed(function () {
            var html = '<p><b>' + this.price() + '</b></p>';
            if (!this.sale()){
                html += '<p><b>'+ this.salePrice() +'</b></p>';
            }
            return html;
        }, this)
    }

    function productList() {
        this.productList = ko.observableArray([]);
        this.addProduct = function (product) {
            for (var key in product){
                if (key == 'price'){
                        setFilterPrice(product[key]())
                }

                if (key === 'color' || key === 'brand' || key === 'model' || key === 'year'){
                    if (attributes[key]().indexOf(product[key]()) === -1) attributes[key].push(product[key]());
                }
            }
            this.productList.push(product)
        }
    }

    function AddProduct() {
        this.title = product.title;
        this.img = product.img;
        this.price = product.price;
        this.salePrice = product.salePrice;
        this.newAction = product.newAction;
        this.sale = product.sale;
        this.rating = product.rating;
        this.colorOptions = attributes.color;
        this.brandOptions = attributes.brand;
        this.modelOptions = attributes.model;
        this.yearOptions = attributes.year;
        this.color = ko.observable();
        this.brand = ko.observable();
        this.model = ko.observable();
        this.year = ko.observable();
        this.addAttribute = function (nameAttribute) {
            var value =  prompt('Enter ' + nameAttribute);
            if (value){
                this[nameAttribute + 'Options'].push(value)

            }
        };
        this.required = ko.observable(false);
        this.addProduct = function () {
            if (this.title() && this.img() && this.price() && this.color() && this.brand() && this.model() && this.year()){
                productList.productList.push(
                    new Product(this.title(), this.img(), this.price(),
                                this.salePrice(), this.color(), this.brand(),
                                this.model(), this.year())
                );
                this.required(false);
                this.cleanForm();
            } else {
                this.required = true;
            }
        }
        this.cleanForm = function () {
            this.title('');
            this.img('');
            this.price('');
            this.salePrice('');
            this.color('');
            this.brand('');
            this.model('');
            this.year('');

        }
    }

    var attributes = new Attributes(),
        product = new Product(),
        addProduct = new AddProduct(),
        productList = new productList();
    ko.applyBindings(addProduct, document.querySelector('#form'));
    ko.applyBindings(attributes, document.querySelector('#filters'));
    ko.applyBindings(productList, document.querySelector('#productList'));

    /* productList.productList.subscribe(function (value) {
        for (var i = 0; i < value.length; i++){
            for (var key in value[i]){
                if (key == 'price'){
                   if (value[i][key]() > +priceFilter.slider('option', 'max')){
                       priceFilter.slider('option', 'max', value[i][key]());
                       priceFilter.slider(value, 1 , value[i][key]());
                       $('#price2').val(value[i][key]());
                   }
                }
            }
        }
     });*/

    /*productList.productList.push(
        new Product('title', 'ima/gal/base/acdelco_335_professional_3 1.png', 40 ,30, false, false, 4,'red', 'bmw', 'x5', 2015),
        new Product('title', 'ima/gal/base/acdelco_335_professional_3 1.png', 40 ,30, false, false, 4,'red', 'bmw', 'x5', 2015),
        new Product('title', 'ima/gal/base/acdelco_335_professional_3 1.png', 40 ,30, false, false, 4,'red', 'bmw', 'x5', 2015),
    );*/
    productList.addProduct(new Product('title', 'ima/gal/mini/acdelco_335_professional_3 1.png', 40 ,30, false, false, 4,'red', 'bmw', 'x5', 2015));
    productList.addProduct(new Product('Audi', 'ima/gal/mini/acdelco_335_professional_3 1.png', 400 ,98, false, false, 5,'black', 'audi', 's8', 2019));
    productList.addProduct(new Product('Audi', 'ima/gal/mini/acdelco_335_professional_3 1.png', 200 ,80, false, false, 5,'green', 'audi', 's8', 2020));
});
